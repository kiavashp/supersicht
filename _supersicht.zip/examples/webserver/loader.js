}),
widget.require('test/index')
//